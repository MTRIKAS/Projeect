const { 
    Client, 
    GatewayIntentBits, 
    Partials, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    Events,
    EmbedBuilder,
    PermissionFlagsBits
} = require('discord.js');

const fs = require('fs');
const readline = require('readline');

// ╔════════════════════════════════════════════════════════════╗
// ║  🔒 SECURITY SETTINGS - CHANGE THESE!                      ║
// ╚════════════════════════════════════════════════════════════╝

const OWNER_ID = "YOUR_DISCORD_ID_HERE";           // Your Discord ID
const ALLOWED_GUILD_ID = "YOUR_SERVER_ID_HERE";    // Your Server ID
const CONFIG_FILE = './config.json';

// ╔════════════════════════════════════════════════════════════╗
// ║  📚 HELPER FUNCTIONS                                       ║
// ╚════════════════════════════════════════════════════════════╝

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Function to ask questions in terminal
function question(text) {
    return new Promise(resolve => {
        rl.question(text, answer => resolve(answer));
    });
}

// Function to load saved config
function loadConfig() {
    if (fs.existsSync(CONFIG_FILE)) {
        const data = fs.readFileSync(CONFIG_FILE);
        return JSON.parse(data);
    }
    return null;
}

// Function to save config
function saveConfig(config) {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
}

// Function to log with timestamp
function log(message, type = 'info') {
    const time = new Date().toLocaleTimeString();
    const icons = {
        'info': '📌',
        'success': '✅',
        'error': '❌',
        'warning': '⚠️',
        'security': '🔒'
    };
    console.log(`[${time}] ${icons[type] || '📌'} ${message}`);
}

// ╔════════════════════════════════════════════════════════════╗
// ║  🚀 MAIN BOT FUNCTION                                      ║
// ╚════════════════════════════════════════════════════════════╝

async function startBot() {
    
    // Welcome message
    console.log('');
    console.log('╔═══════════════════════════════════════════════════╗');
    console.log('║        🤖 ROBLOX ASSET MANAGER BOT v2.0           ║');
    console.log('║           Protected & Feature-Rich                ║');
    console.log('╚═══════════════════════════════════════════════════╝');
    console.log('');

    // Load or create config
    let config = loadConfig();

    if (!config) {
        // First time setup
        console.log('⚙️  First Time Setup\n');
        console.log('─'.repeat(50));
        
        const token = await question('📝 Enter Bot TOKEN: ');
        const logChannelId = await question('📝 Enter LOG CHANNEL ID: ');
        const prefix = await question('📝 Enter Prefix (default: !): ') || '!';
        
        config = {
            token: token.trim(),
            logChannelId: logChannelId.trim(),
            prefix: prefix.trim(),
            cooldownTime: 5000,
            maxFileSize: 25 * 1024 * 1024, // 25MB
            allowedExtensions: ['.rbx', '.rbxm', '.rbxl'],
            createdAt: new Date().toISOString()
        };
        
        saveConfig(config);
        console.log('\n✅ Config saved successfully!\n');
        
    } else {
        // Config exists
        console.log('✅ Config loaded from config.json\n');
        console.log('─'.repeat(50));
        console.log(`📌 Token: ${config.token.slice(0, 20)}...`);
        console.log(`📌 Log Channel: ${config.logChannelId}`);
        console.log(`📌 Prefix: ${config.prefix || '!'}`);
        console.log('─'.repeat(50));
        
        // Skip prompt if running under PM2
        if (!process.env.PM2_HOME) {
            const reset = await question('\n🔄 Change config? (y/n): ');
            
            if (reset.toLowerCase() === 'y') {
                const token = await question('📝 New TOKEN (Enter to skip): ');
                const logChannelId = await question('📝 New LOG CHANNEL ID (Enter to skip): ');
                const prefix = await question('📝 New Prefix (Enter to skip): ');
                
                if (token) config.token = token.trim();
                if (logChannelId) config.logChannelId = logChannelId.trim();
                if (prefix) config.prefix = prefix.trim();
                
                saveConfig(config);
                console.log('\n✅ Config updated!\n');
            }
        }
    }

    rl.close();

    // ╔════════════════════════════════════════════════════════════╗
    // ║  🤖 CREATE DISCORD CLIENT                                  ║
    // ╚════════════════════════════════════════════════════════════╝

    const client = new Client({
        intents: [
            GatewayIntentBits.Guilds,
            GatewayIntentBits.GuildMessages,
            GatewayIntentBits.MessageContent,
            GatewayIntentBits.DirectMessages,
            GatewayIntentBits.GuildMembers
        ],
        partials: [Partials.Channel, Partials.Message, Partials.User]
    });

    // Storage for user sessions and cooldowns
    const userState = new Map();
    const cooldowns = new Map();
    
    // Statistics
    const stats = {
        submissions: 0,
        startTime: Date.now()
    };

    // ╔════════════════════════════════════════════════════════════╗
    // ║  📡 BOT READY EVENT                                        ║
    // ╚════════════════════════════════════════════════════════════╝

    client.once(Events.ClientReady, async (c) => {
        console.log('');
        console.log('╔═══════════════════════════════════════════════════╗');
        console.log(`║  ✅ Bot Online: ${c.user.tag.padEnd(33)}║`);
        console.log(`║  📊 Servers: ${c.guilds.cache.size.toString().padEnd(37)}║`);
        console.log(`║  👥 Users: ${c.users.cache.size.toString().padEnd(39)}║`);
        console.log('╚═══════════════════════════════════════════════════╝');
        console.log('');
        
        // Set bot status
        client.user.setPresence({
            activities: [{ 
                name: '📦 Asset Submissions',
                type: 3 // Watching
            }],
            status: 'online'
        });

        // 🔒 SECURITY: Leave unauthorized servers
        log('Checking server authorization...', 'security');
        
        for (const [guildId, guild] of c.guilds.cache) {
            if (guildId !== ALLOWED_GUILD_ID) {
                log(`Leaving unauthorized server: ${guild.name}`, 'warning');
                await guild.leave().catch(() => {});
            }
        }
        
        log('Security check complete!', 'success');
        
        // Show available commands
        console.log('');
        console.log('📚 Available Commands:');
        console.log('─'.repeat(50));
        console.log(`   ${config.prefix}setup    - Create submission button`);
        console.log(`   ${config.prefix}stats    - Show bot statistics`);
        console.log(`   ${config.prefix}ping     - Check bot latency`);
        console.log(`   ${config.prefix}help     - Show help menu`);
        console.log(`   ${config.prefix}clear    - Clear messages (Admin)`);
        console.log(`   ${config.prefix}announce - Send announcement (Owner)`);
        console.log('─'.repeat(50));
        console.log('');
    });

    // ╔════════════════════════════════════════════════════════════╗
    // ║  🔒 SECURITY: GUILD JOIN CHECK                             ║
    // ╚════════════════════════════════════════════════════════════╝

    client.on(Events.GuildCreate, async (guild) => {
        if (guild.id !== ALLOWED_GUILD_ID) {
            log(`Unauthorized server join attempt: ${guild.name} (${guild.id})`, 'security');
            
            try {
                const owner = await guild.fetchOwner();
                
                const warningEmbed = new EmbedBuilder()
                    .setColor(0xED4245)
                    .setTitle('⛔ Unauthorized Access')
                    .setDescription('This is a private bot. I am not allowed to be in this server.')
                    .setFooter({ text: 'Leaving server...' })
                    .setTimestamp();
                
                await owner.send({ embeds: [warningEmbed] }).catch(() => {});
            } catch (err) {
                // Ignore DM errors
            }
            
            await guild.leave();
            log(`Left unauthorized server: ${guild.name}`, 'security');
        }
    });

    // ╔════════════════════════════════════════════════════════════╗
    // ║  💬 MESSAGE COMMANDS                                       ║
    // ╚════════════════════════════════════════════════════════════╝

    client.on(Events.MessageCreate, async (message) => {
        // Ignore bots
        if (message.author.bot) return;
        
        // Handle DM submissions (separate handler below)
        if (!message.guild) return;
        
        // Check if in allowed server
        if (message.guildId !== ALLOWED_GUILD_ID) return;
        
        const prefix = config.prefix || '!';
        if (!message.content.startsWith(prefix)) return;
        
        const args = message.content.slice(prefix.length).trim().split(/ +/);
        const command = args.shift().toLowerCase();

        // ═══════════════════════════════════════════════════
        // 📤 SETUP COMMAND - Create submission button
        // ═══════════════════════════════════════════════════
        if (command === 'setup') {
            // Check admin permission
            if (!message.member.permissions.has(PermissionFlagsBits.Administrator)) {
                return message.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(0xED4245)
                        .setDescription('❌ You need Administrator permission!')
                    ]
                }).then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
            }
            
            const setupEmbed = new EmbedBuilder()
                .setColor(0x5865F2)
                .setTitle('📦 Roblox Asset Submission')
                .setDescription('Click the button below to submit your Roblox asset file!')
                .addFields(
                    { 
                        name: '📁 Accepted Files', 
                        value: '```\n.rbx  .rbxm  .rbxl\n```', 
                        inline: true 
                    },
                    { 
                        name: '📏 Max Size', 
                        value: '```\n25 MB\n```', 
                        inline: true 
                    },
                    { 
                        name: '⏱️ Cooldown', 
                        value: '```\n5 seconds\n```', 
                        inline: true 
                    }
                )
                .addFields({
                    name: '📋 How to Submit',
                    value: '1️⃣ Click the button below\n2️⃣ Check your DMs\n3️⃣ Send your file\n4️⃣ Enter asset name\n5️⃣ Done!'
                })
                .setImage('https://i.imgur.com/AfFp7pu.png') // Optional banner
                .setFooter({ text: '🤖 Roblox Asset Manager' })
                .setTimestamp();

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('start_submission')
                        .setLabel('Submit Asset')
                        .setStyle(ButtonStyle.Success)
                        .setEmoji('📤'),
                    new ButtonBuilder()
                        .setCustomId('view_info')
                        .setLabel('More Info')
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji('ℹ️')
                );

            await message.channel.send({ embeds: [setupEmbed], components: [row] });
            await message.delete().catch(() => {});
            
            log(`${message.author.tag} created submission panel`, 'success');
        }

        // ═══════════════════════════════════════════════════
        // 📊 STATS COMMAND - Show statistics
        // ═══════════════════════════════════════════════════
        else if (command === 'stats') {
            const uptime = Math.floor((Date.now() - stats.startTime) / 1000);
            const hours = Math.floor(uptime / 3600);
            const minutes = Math.floor((uptime % 3600) / 60);
            const seconds = uptime % 60;
            
            const statsEmbed = new EmbedBuilder()
                .setColor(0x5865F2)
                .setTitle('📊 Bot Statistics')
                .addFields(
                    { name: '⏱️ Uptime', value: `\`${hours}h ${minutes}m ${seconds}s\``, inline: true },
                    { name: '📦 Submissions', value: `\`${stats.submissions}\``, inline: true },
                    { name: '🏓 Ping', value: `\`${client.ws.ping}ms\``, inline: true },
                    { name: '📊 Memory', value: `\`${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB\``, inline: true },
                    { name: '👥 Users', value: `\`${client.users.cache.size}\``, inline: true },
                    { name: '📡 Servers', value: `\`${client.guilds.cache.size}\``, inline: true }
                )
                .setFooter({ text: '🤖 Roblox Asset Manager' })
                .setTimestamp();

            await message.reply({ embeds: [statsEmbed] });
        }

        // ═══════════════════════════════════════════════════
        // 🏓 PING COMMAND - Check latency
        // ═══════════════════════════════════════════════════
        else if (command === 'ping') {
            const sent = await message.reply({ 
                embeds: [new EmbedBuilder()
                    .setColor(0xFFA500)
                    .setDescription('🏓 Pinging...')
                ]
            });
            
            const latency = sent.createdTimestamp - message.createdTimestamp;
            
            await sent.edit({
                embeds: [new EmbedBuilder()
                    .setColor(0x57F287)
                    .setTitle('🏓 Pong!')
                    .addFields(
                        { name: '📡 Bot Latency', value: `\`${latency}ms\``, inline: true },
                        { name: '💓 API Latency', value: `\`${client.ws.ping}ms\``, inline: true }
                    )
                ]
            });
        }

        // ═══════════════════════════════════════════════════
        // ❓ HELP COMMAND - Show help menu
        // ═══════════════════════════════════════════════════
        else if (command === 'help') {
            const helpEmbed = new EmbedBuilder()
                .setColor(0x5865F2)
                .setTitle('📚 Help Menu')
                .setDescription('Here are all available commands:')
                .addFields(
                    { 
                        name: '👤 User Commands', 
                        value: `\`${prefix}ping\` - Check bot latency\n\`${prefix}stats\` - View statistics\n\`${prefix}help\` - Show this menu`
                    },
                    { 
                        name: '👑 Admin Commands', 
                        value: `\`${prefix}setup\` - Create submission panel\n\`${prefix}clear [amount]\` - Delete messages`
                    },
                    { 
                        name: '🔧 Owner Commands', 
                        value: `\`${prefix}announce [message]\` - Send announcement\n\`${prefix}reload\` - Reload configuration`
                    }
                )
                .setFooter({ text: `Prefix: ${prefix}` })
                .setTimestamp();

            await message.reply({ embeds: [helpEmbed] });
        }

        // ═══════════════════════════════════════════════════
        // 🗑️ CLEAR COMMAND - Delete messages
        // ═══════════════════════════════════════════════════
        else if (command === 'clear') {
            if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
                return message.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(0xED4245)
                        .setDescription('❌ You need Manage Messages permission!')
                    ]
                }).then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
            }
            
            const amount = parseInt(args[0]) || 10;
            
            if (amount < 1 || amount > 100) {
                return message.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(0xED4245)
                        .setDescription('❌ Amount must be between 1-100!')
                    ]
                });
            }
            
            await message.delete().catch(() => {});
            const deleted = await message.channel.bulkDelete(amount, true);
            
            const confirmMsg = await message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(0x57F287)
                    .setDescription(`✅ Deleted ${deleted.size} messages!`)
                ]
            });
            
            setTimeout(() => confirmMsg.delete().catch(() => {}), 3000);
            
            log(`${message.author.tag} cleared ${deleted.size} messages`, 'info');
        }

        // ═══════════════════════════════════════════════════
        // 📢 ANNOUNCE COMMAND - Send announcement (Owner only)
        // ═══════════════════════════════════════════════════
        else if (command === 'announce') {
            if (message.author.id !== OWNER_ID) {
                return message.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(0xED4245)
                        .setDescription('❌ Only the bot owner can use this!')
                    ]
                });
            }
            
            const announcement = args.join(' ');
            
            if (!announcement) {
                return message.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(0xED4245)
                        .setDescription(`❌ Usage: \`${prefix}announce [message]\``)
                    ]
                });
            }
            
            const announceEmbed = new EmbedBuilder()
                .setColor(0xFFD700)
                .setTitle('📢 Announcement')
                .setDescription(announcement)
                .setFooter({ text: `From: ${message.author.tag}` })
                .setTimestamp();

            await message.channel.send({ embeds: [announceEmbed] });
            await message.delete().catch(() => {});
        }

        // ═══════════════════════════════════════════════════
        // 🔄 RELOAD COMMAND - Reload config (Owner only)
        // ═══════════════════════════════════════════════════
        else if (command === 'reload') {
            if (message.author.id !== OWNER_ID) {
                return message.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(0xED4245)
                        .setDescription('❌ Only the bot owner can use this!')
                    ]
                });
            }
            
            const newConfig = loadConfig();
            if (newConfig) {
                Object.assign(config, newConfig);
                
                await message.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(0x57F287)
                        .setDescription('✅ Configuration reloaded!')
                    ]
                });
                
                log('Configuration reloaded by owner', 'success');
            }
        }
    });

    // ╔════════════════════════════════════════════════════════════╗
    // ║  🔘 BUTTON INTERACTIONS                                    ║
    // ╚════════════════════════════════════════════════════════════╝

    client.on(Events.InteractionCreate, async (interaction) => {
        if (!interaction.isButton()) return;

        const userId = interaction.user.id;

        // ═══════════════════════════════════════════════════
        // ℹ️ INFO BUTTON
        // ═══════════════════════════════════════════════════
        if (interaction.customId === 'view_info') {
            const infoEmbed = new EmbedBuilder()
                .setColor(0x5865F2)
                .setTitle('ℹ️ Submission Information')
                .setDescription('Here\'s everything you need to know about submitting assets:')
                .addFields(
                    { 
                        name: '📁 Supported Formats', 
                        value: '• `.rbx` - Roblox XML format\n• `.rbxm` - Roblox Model\n• `.rbxl` - Roblox Level/Place'
                    },
                    { 
                        name: '⚠️ Rules', 
                        value: '• No inappropriate content\n• No stolen assets\n• Maximum 25MB per file\n• One submission at a time'
                    },
                    { 
                        name: '❓ Having Issues?', 
                        value: 'Make sure your DMs are open so the bot can message you!'
                    }
                )
                .setFooter({ text: 'Click Submit Asset to begin!' });

            await interaction.reply({ embeds: [infoEmbed], ephemeral: true });
        }

        // ═══════════════════════════════════════════════════
        // 📤 SUBMIT BUTTON
        // ═══════════════════════════════════════════════════
        else if (interaction.customId === 'start_submission') {
            
            // Check cooldown
            if (cooldowns.has(userId)) {
                const timeLeft = (cooldowns.get(userId) + (config.cooldownTime || 5000) - Date.now()) / 1000;
                
                if (timeLeft > 0) {
                    return interaction.reply({
                        embeds: [new EmbedBuilder()
                            .setColor(0xFFA500)
                            .setTitle('⏳ Cooldown Active')
                            .setDescription(`Please wait **${timeLeft.toFixed(1)} seconds** before submitting again.`)
                        ],
                        ephemeral: true
                    });
                }
            }

            // Check if already in process
            if (userState.has(userId)) {
                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(0xFFA500)
                        .setTitle('⚠️ Submission In Progress')
                        .setDescription('You already have an active submission. Check your DMs!')
                    ],
                    ephemeral: true
                });
            }

            // Start submission process
            userState.set(userId, { 
                step: 1, 
                fileUrl: null, 
                fileName: null,
                startTime: Date.now()
            });

            try {
                const dmEmbed = new EmbedBuilder()
                    .setColor(0x5865F2)
                    .setTitle('📂 Step 1/2 - Upload Your File')
                    .setDescription('Please send me your Roblox asset file.')
                    .addFields(
                        { name: '📁 Accepted Formats', value: '`.rbx` `.rbxm` `.rbxl`', inline: true },
                        { name: '📏 Max Size', value: '25 MB', inline: true }
                    )
                    .setFooter({ text: 'Step 1 of 2 • You have 5 minutes' })
                    .setTimestamp();

                const cancelRow = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId('cancel_submission')
                            .setLabel('Cancel')
                            .setStyle(ButtonStyle.Danger)
                            .setEmoji('❌')
                    );

                await interaction.user.send({ embeds: [dmEmbed], components: [cancelRow] });
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(0x57F287)
                        .setTitle('📩 Check Your DMs!')
                        .setDescription('I sent you a direct message. Please check your DMs to continue.')
                    ],
                    ephemeral: true
                });
                
                log(`${interaction.user.tag} started submission`, 'info');
                
                // Auto-cancel after 5 minutes
                setTimeout(() => {
                    if (userState.has(userId)) {
                        userState.delete(userId);
                        interaction.user.send({
                            embeds: [new EmbedBuilder()
                                .setColor(0xED4245)
                                .setTitle('⏰ Submission Timed Out')
                                .setDescription('Your submission was cancelled due to inactivity.')
                            ]
                        }).catch(() => {});
                    }
                }, 5 * 60 * 1000);
                
            } catch (error) {
                userState.delete(userId);
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(0xED4245)
                        .setTitle('❌ Cannot Send DM')
                        .setDescription('I couldn\'t send you a direct message.\n\n**How to fix:**\n1. Go to Privacy Settings\n2. Enable "Allow DMs from server members"\n3. Try again')
                    ],
                    ephemeral: true
                });
            }
        }

        // ═══════════════════════════════════════════════════
        // ❌ CANCEL BUTTON
        // ═══════════════════════════════════════════════════
        else if (interaction.customId === 'cancel_submission') {
            if (userState.has(userId)) {
                userState.delete(userId);
                
                await interaction.update({
                    embeds: [new EmbedBuilder()
                        .setColor(0xED4245)
                        .setTitle('❌ Submission Cancelled')
                        .setDescription('Your submission has been cancelled.')
                    ],
                    components: []
                });
                
                log(`${interaction.user.tag} cancelled submission`, 'info');
            }
        }
    });

    // ╔════════════════════════════════════════════════════════════╗
    // ║  📨 DM MESSAGE HANDLER                                     ║
    // ╚════════════════════════════════════════════════════════════╝

    client.on(Events.MessageCreate, async (message) => {
        // Only handle DMs from non-bots
        if (message.guild || message.author.bot) return;

        const userId = message.author.id;
        const state = userState.get(userId);
        
        if (!state) return;

        // ═══════════════════════════════════════════════════
        // 📂 STEP 1: FILE UPLOAD
        // ═══════════════════════════════════════════════════
        if (state.step === 1) {
            const file = message.attachments.first();
            
            // Check if file exists
            if (!file) {
                return message.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(0xED4245)
                        .setTitle('❌ No File Detected')
                        .setDescription('Please send a **file**, not a text message.')
                        .addFields({ name: 'Accepted Formats', value: '`.rbx` `.rbxm` `.rbxl`' })
                    ]
                });
            }

            // Check file extension
            const fileName = file.name.toLowerCase();
            const validExtensions = config.allowedExtensions || ['.rbx', '.rbxm', '.rbxl'];
            const hasValidExtension = validExtensions.some(ext => fileName.endsWith(ext));
            
            if (!hasValidExtension) {
                return message.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(0xED4245)
                        .setTitle('❌ Invalid File Format')
                        .setDescription(`Only these formats are accepted:\n\`${validExtensions.join('` `')}\``)
                    ]
                });
            }

            // Check file size (25MB max)
            const maxSize = config.maxFileSize || 25 * 1024 * 1024;
            if (file.size > maxSize) {
                return message.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(0xED4245)
                        .setTitle('❌ File Too Large')
                        .setDescription(`Maximum file size is **${(maxSize / 1024 / 1024).toFixed(0)}MB**.\nYour file: **${(file.size / 1024 / 1024).toFixed(2)}MB**`)
                    ]
                });
            }

            // Save file info and move to step 2
            state.fileUrl = file.url;
            state.fileName = file.name;
            state.fileSize = file.size;
            state.step = 2;
            userState.set(userId, state);

            const step2Embed = new EmbedBuilder()
                .setColor(0x5865F2)
                .setTitle('✏️ Step 2/2 - Asset Name')
                .setDescription('Great! Now please enter a **name** for your asset.')
                .addFields(
                    { name: '📁 File', value: `\`${file.name}\``, inline: true },
                    { name: '📏 Size', value: `\`${(file.size / 1024).toFixed(2)} KB\``, inline: true }
                )
                .setFooter({ text: 'Step 2 of 2 • Type the name below' })
                .setTimestamp();

            await message.reply({ embeds: [step2Embed] });
        }
        
        // ═══════════════════════════════════════════════════
        // ✏️ STEP 2: ASSET NAME
        // ═══════════════════════════════════════════════════
        else if (state.step === 2) {
            const assetName = message.content.trim();
            
            // Validate name
            if (assetName.length < 2) {
                return message.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(0xED4245)
                        .setDescription('❌ Name must be at least 2 characters!')
                    ]
                });
            }
            
            if (assetName.length > 100) {
                return message.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(0xED4245)
                        .setDescription('❌ Name cannot exceed 100 characters!')
                    ]
                });
            }

            try {
                // Send to log channel
                const logChannel = await client.channels.fetch(config.logChannelId);
                
                const logEmbed = new EmbedBuilder()
                    .setColor(0x57F287)
                    .setTitle('📦 New Asset Submission')
                    .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
                    .addFields(
                        { name: '👤 Submitted By', value: `<@${userId}>\n\`${message.author.tag}\``, inline: true },
                        { name: '🆔 User ID', value: `\`${userId}\``, inline: true },
                        { name: '\u200b', value: '\u200b', inline: true },
                        { name: '📝 Asset Name', value: `\`${assetName}\``, inline: true },
                        { name: '📁 File Name', value: `\`${state.fileName}\``, inline: true },
                        { name: '📏 File Size', value: `\`${(state.fileSize / 1024).toFixed(2)} KB\``, inline: true }
                    )
                    .setTimestamp()
                    .setFooter({ text: `Submission #${stats.submissions + 1}` });

                // Send with file attachment
                await logChannel.send({ 
                    embeds: [logEmbed], 
                    files: [{
                        attachment: state.fileUrl,
                        name: state.fileName
                    }]
                });

                // Success message to user
                const successEmbed = new EmbedBuilder()
                    .setColor(0x57F287)
                    .setTitle('✅ Submission Successful!')
                    .setDescription('Your asset has been submitted successfully!')
                    .addFields(
                        { name: '📝 Asset Name', value: `\`${assetName}\``, inline: true },
                        { name: '📁 File', value: `\`${state.fileName}\``, inline: true }
                    )
                    .setFooter({ text: 'Thank you for your submission!' })
                    .setTimestamp();

                await message.reply({ embeds: [successEmbed] });
                
                // Update stats and cleanup
                stats.submissions++;
                userState.delete(userId);
                cooldowns.set(userId, Date.now());
                
                log(`${message.author.tag} submitted: ${assetName}`, 'success');

            } catch (error) {
                console.error('Submission error:', error);
                
                await message.reply({
                    embeds: [new EmbedBuilder()
                        .setColor(0xED4245)
                        .setTitle('⚠️ Submission Failed')
                        .setDescription('Something went wrong. Please try again later.')
                    ]
                });
                
                userState.delete(userId);
                log(`Submission failed for ${message.author.tag}: ${error.message}`, 'error');
            }
        }
    });

    // ╔════════════════════════════════════════════════════════════╗
    // ║  🔌 BOT LOGIN                                              ║
    // ╚════════════════════════════════════════════════════════════╝

    console.log('🔄 Connecting to Discord...\n');
    
    client.login(config.token).catch(err => {
        console.log('');
        console.log('╔═══════════════════════════════════════════════════╗');
        console.log('║  ❌ CONNECTION FAILED                             ║');
        console.log('║                                                   ║');
        console.log('║  The token is invalid or expired.                 ║');
        console.log('║  Delete config.json and restart the bot.          ║');
        console.log('╚═══════════════════════════════════════════════════╝');
        console.log('');
        
        if (fs.existsSync(CONFIG_FILE)) {
            fs.unlinkSync(CONFIG_FILE);
        }
        process.exit(1);
    });
}

// ╔════════════════════════════════════════════════════════════╗
// ║  🚀 START THE BOT                                          ║
// ╚════════════════════════════════════════════════════════════╝

startBot();